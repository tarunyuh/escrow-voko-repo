
import React, { useState } from 'react';
import { ComplianceResult } from '../types';

interface ResultsDisplayProps {
  results: ComplianceResult;
}

const ResultsDisplay: React.FC<ResultsDisplayProps> = ({ results }) => {
  const [activeView, setActiveView] = useState<'checklist' | 'analysis' | 'metrics'>('checklist');
  const [selectedItem, setSelectedItem] = useState<number | null>(null);

  const statusColors = {
    implemented: 'bg-emerald-500',
    missing: 'bg-rose-500',
    partial: 'bg-amber-500'
  };

  const statusTextColors = {
    implemented: 'text-emerald-600',
    missing: 'text-rose-600',
    partial: 'text-amber-600'
  };

  const statusBgs = {
    implemented: 'bg-emerald-50',
    missing: 'bg-rose-50',
    partial: 'bg-amber-50'
  };

  return (
    <div className="space-y-8 pb-10 animate-in fade-in duration-500">
      <div className="flex bg-white p-1 rounded-xl w-fit mx-auto border border-slate-200 shadow-sm no-print overflow-x-auto ring-1 ring-slate-100">
        {(['checklist', 'analysis', 'metrics'] as const).map(v => (
          <button 
            key={v}
            onClick={() => setActiveView(v)}
            className={`px-6 py-2 text-[10px] font-black uppercase tracking-widest rounded-lg transition-all whitespace-nowrap ${activeView === v ? 'bg-slate-950 text-white' : 'text-slate-400 hover:text-slate-700'}`}
          >
            {v === 'checklist' ? 'Integrity Matrix' : v === 'analysis' ? 'Report' : 'Metrics'}
          </button>
        ))}
      </div>

      {activeView === 'checklist' && (
        <div className="space-y-6 animate-in slide-in-from-bottom-4 duration-500">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
            <div className="bg-white p-8 rounded-2xl shadow-sm border border-slate-100 text-center">
              <h3 className="text-[10px] font-black text-slate-400 uppercase tracking-widest mb-4">Integrity Score</h3>
              <div className="text-6xl font-black text-slate-900 italic leading-none">{results.score}%</div>
            </div>
            <div className="md:col-span-3 bg-slate-900 p-8 rounded-2xl shadow-lg flex items-center border border-white/5">
               <div className="w-full grid grid-cols-3 gap-6 text-center">
                  <div>
                    <p className="text-[9px] font-black text-slate-500 uppercase tracking-widest mb-2 italic">Passed</p>
                    <p className="text-4xl font-black text-emerald-400 italic leading-none">{results.intentChecklist.filter(i => i.status === 'implemented').length}</p>
                  </div>
                  <div>
                    <p className="text-[9px] font-black text-slate-500 uppercase tracking-widest mb-2 italic">Partial</p>
                    <p className="text-4xl font-black text-amber-400 italic leading-none">{results.intentChecklist.filter(i => i.status === 'partial').length}</p>
                  </div>
                  <div>
                    <p className="text-[9px] font-black text-slate-500 uppercase tracking-widest mb-2 italic">Critical</p>
                    <p className="text-4xl font-black text-rose-500 italic leading-none">{results.intentChecklist.filter(i => i.status === 'missing').length}</p>
                  </div>
               </div>
            </div>
          </div>

          <div className="bg-white rounded-2xl border border-slate-100 overflow-hidden shadow-sm">
            <div className="divide-y divide-slate-50">
              {results.intentChecklist.map((item, idx) => (
                <div key={idx} className="p-6 hover:bg-slate-50 transition-all cursor-pointer group" onClick={() => setSelectedItem(selectedItem === idx ? null : idx)}>
                  <div className="flex justify-between items-center gap-6">
                    <div className="flex gap-6 items-center">
                       <div className={`shrink-0 w-10 h-10 rounded-lg flex items-center justify-center shadow-sm ${statusBgs[item.status]}`}>
                          <div className={`w-3 h-3 rounded-full ${statusColors[item.status]}`}></div>
                       </div>
                       <div>
                          <h4 className="text-lg font-black text-slate-900 tracking-tight italic leading-none">{item.requirement}</h4>
                          <span className={`text-[8px] font-black uppercase tracking-widest mt-2 block ${statusTextColors[item.status]}`}>{item.status}</span>
                       </div>
                    </div>
                    <p className="text-2xl font-black text-slate-900 italic leading-none">{item.confidence}%</p>
                  </div>
                  
                  {selectedItem === idx && (
                    <div className="mt-8 pl-16 space-y-6 animate-in slide-in-from-top-2">
                       <div className="p-6 bg-slate-50 rounded-2xl border border-slate-200">
                          <p className="text-sm font-serif text-slate-700 leading-relaxed italic">{item.explanation}</p>
                       </div>
                       {item.snippet && (
                         <div className="bg-slate-900 rounded-xl p-6 font-mono text-[11px] text-blue-200 overflow-x-auto shadow-inner">
                            <pre><code>{item.snippet}</code></pre>
                         </div>
                       )}
                    </div>
                  )}
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {activeView === 'analysis' && (
        <div className="bg-white p-10 rounded-3xl border border-slate-200 shadow-sm animate-in zoom-in-95 duration-500">
          <div className="prose prose-slate max-w-none">
            <div className="text-lg font-serif text-slate-800 leading-relaxed italic whitespace-pre-wrap">
              {results.overallAnalysis}
            </div>
          </div>
        </div>
      )}

      {activeView === 'metrics' && (
        <div className="grid grid-cols-2 md:grid-cols-4 gap-6 animate-in slide-in-from-top-4 duration-500">
          {[
            { label: 'Nodes', value: results.totalFilesScanned, sub: 'Analyzed' },
            { label: 'Line Count', value: results.metrics.totalLines.toLocaleString(), sub: 'Scanned' },
            { label: 'Diversity', value: results.metrics.fileDiversity.length, sub: 'Extensions' },
            { label: 'Complexity', value: results.metrics.maxNestingDepth, sub: 'Nesting Level' }
          ].map((m, i) => (
            <div key={i} className="bg-white p-6 rounded-2xl border border-slate-100 text-center shadow-sm hover:translate-y-[-4px] transition-all">
              <p className="text-[9px] font-black text-slate-400 uppercase tracking-widest mb-2 italic">{m.label}</p>
              <p className="text-3xl font-black text-slate-900 italic leading-none">{m.value}</p>
              <p className="text-[8px] font-black text-slate-300 uppercase tracking-widest mt-2 italic">{m.sub}</p>
            </div>
          ))}
        </div>
      )}
    </div>
  );
};

export default ResultsDisplay;
