
import React, { useState, useRef } from 'react';

interface AnalysisFormProps {
  onAnalyze: (source: { url?: string; zipFile?: File }, rules: string) => void;
  isLoading: boolean;
}

const AnalysisForm: React.FC<AnalysisFormProps> = ({ onAnalyze, isLoading }) => {
  const [activeTab, setActiveTab] = useState<'url' | 'zip'>('url');
  const [url, setUrl] = useState('');
  const [zipFile, setZipFile] = useState<File | null>(null);
  const [rules, setRules] = useState('');
  const [isDragging, setIsDragging] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!rules.trim()) return;
    
    if (activeTab === 'url' && url) {
      onAnalyze({ url }, rules);
    } else if (activeTab === 'zip' && zipFile) {
      onAnalyze({ zipFile }, rules);
    }
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file && file.name.endsWith('.zip')) {
      setZipFile(file);
    }
  };

  const handleDragOver = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(true);
  };

  const handleDragLeave = () => setIsDragging(false);

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(false);
    const file = e.dataTransfer.files?.[0];
    if (file && file.name.endsWith('.zip')) {
      setZipFile(file);
    }
  };

  return (
    <div className="bg-white p-8 rounded-2xl shadow-sm border border-slate-200">
      <div className="flex justify-between items-center mb-6">
        <h2 className="text-lg font-black italic">Start Audit</h2>
        <div className="flex bg-slate-100 p-1 rounded-lg">
          <button 
            type="button"
            onClick={() => setActiveTab('url')}
            className={`px-4 py-1.5 text-[9px] font-black uppercase tracking-widest rounded transition ${activeTab === 'url' ? 'bg-white shadow-sm text-blue-600' : 'text-slate-500 hover:text-slate-700'}`}
          >
            GitHub
          </button>
          <button 
            type="button"
            onClick={() => setActiveTab('zip')}
            className={`px-4 py-1.5 text-[9px] font-black uppercase tracking-widest rounded transition ${activeTab === 'zip' ? 'bg-white shadow-sm text-blue-600' : 'text-slate-500 hover:text-slate-700'}`}
          >
            ZIP
          </button>
        </div>
      </div>

      <form onSubmit={handleSubmit} className="space-y-6">
        {activeTab === 'url' ? (
          <div>
            <label className="block text-[9px] font-black uppercase tracking-widest text-slate-400 mb-2 ml-2">GitHub URL</label>
            <input
              type="url"
              placeholder="https://github.com/..."
              className="w-full px-4 py-3 rounded-xl border border-slate-200 bg-slate-50 font-bold focus:ring-4 focus:ring-blue-500/5 focus:border-blue-500 outline-none transition"
              value={url}
              onChange={(e) => setUrl(e.target.value)}
              required={activeTab === 'url'}
              disabled={isLoading}
            />
          </div>
        ) : (
          <div>
            <label className="block text-[9px] font-black uppercase tracking-widest text-slate-400 mb-2 ml-2">Project Archive</label>
            <div 
              onClick={() => fileInputRef.current?.click()}
              onDragOver={handleDragOver}
              onDragLeave={handleDragLeave}
              onDrop={handleDrop}
              className={`border-2 border-dashed rounded-xl p-8 text-center cursor-pointer transition-all duration-200 ${
                isDragging ? 'border-blue-500 bg-blue-50' : 
                zipFile ? 'border-emerald-500 bg-emerald-50' : 'border-slate-200 hover:border-slate-300'
              }`}
            >
              <input 
                type="file" 
                ref={fileInputRef} 
                onChange={handleFileChange} 
                className="hidden" 
                accept=".zip"
              />
              <div className="flex flex-col items-center">
                {zipFile ? (
                  <>
                    <span className="text-xs font-black italic">{zipFile.name}</span>
                    <span className="text-[8px] text-slate-400 mt-1 uppercase tracking-widest">Ready for scan</span>
                  </>
                ) : (
                  <>
                    <span className="text-[10px] font-black uppercase tracking-widest text-slate-400">Drop project ZIP or click to browse</span>
                  </>
                )}
              </div>
            </div>
          </div>
        )}

        <div>
          <label className="block text-[9px] font-black uppercase tracking-widest text-slate-400 mb-2 ml-2">Audit Description</label>
          <textarea
            placeholder="Describe technical requirements..."
            rows={4}
            className="w-full px-4 py-3 rounded-xl border border-slate-200 bg-slate-50 font-bold focus:ring-4 focus:ring-blue-500/5 focus:border-blue-500 outline-none transition resize-none"
            value={rules}
            onChange={(e) => setRules(e.target.value)}
            disabled={isLoading}
            required
          />
        </div>

        <button
          type="submit"
          disabled={isLoading || (activeTab === 'url' && !url) || (activeTab === 'zip' && !zipFile) || !rules.trim()}
          className={`w-full py-4 px-4 rounded-xl font-black text-[10px] uppercase tracking-widest text-white transition shadow-lg ${
            isLoading ? 'bg-slate-400' : 'bg-slate-900 hover:bg-black'
          }`}
        >
          {isLoading ? 'SYNCING NODES...' : `INITIALIZE ${activeTab.toUpperCase()} AUDIT`}
        </button>
      </form>
    </div>
  );
};

export default AnalysisForm;
