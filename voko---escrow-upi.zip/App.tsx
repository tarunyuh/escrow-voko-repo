
import React, { useState, useEffect, useRef } from 'react';
import html2canvas from 'html2canvas';
import { jsPDF } from 'jspdf';
import { 
  TransactionDetails, 
  UserRole, 
  EscrowStatus, 
  RepoFile,
  TransactionLog
} from './types';
import { parseGitHubUrl, fetchRepoFiles } from './services/githubService';
import { performPseudoAnalysis, generateBSReport } from './services/pseudoHeuristicService';
import { processZipFile } from './services/zipService';
import ResultsDisplay from './components/ResultsDisplay';

const DATABASE_KEY = 'voko_escrow_ledger_v2';
const ESCROW_POOL_UPI = '9535795496@pthdfc';

const App: React.FC = () => {
  const [role, setRole] = useState<UserRole>('seller');
  const [sellerSubView, setSellerSubView] = useState<'create' | 'dashboard'>('dashboard');
  const [sourceType, setSourceType] = useState<'github' | 'zip'>('github');
  const [zipFiles, setZipFiles] = useState<RepoFile[] | null>(null);
  const [buyerSearch, setBuyerSearch] = useState('');
  
  const [transactions, setTransactions] = useState<TransactionDetails[]>([]);
  const [activeTxnId, setActiveTxnId] = useState<string | null>(null);
  const [adminTxnId, setAdminTxnId] = useState<string | null>(null);
  const [isProcessing, setIsProcessing] = useState(false);
  const [isPaying, setIsPaying] = useState(false);
  const [showAdminSettlement, setShowAdminSettlement] = useState(false);
  const [isExporting, setIsExporting] = useState(false);
  const reportRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const data = localStorage.getItem(DATABASE_KEY);
    if (data) {
      try {
        setTransactions(JSON.parse(data));
      } catch (e) {
        setTransactions([]);
      }
    }
  }, []);

  useEffect(() => {
    localStorage.setItem(DATABASE_KEY, JSON.stringify(transactions));
  }, [transactions]);

  const dbUpdate = (id: string, updates: Partial<TransactionDetails>, log?: { msg: string, type: TransactionLog['type'] }) => {
    setTransactions(prev => prev.map(t => {
      if (t.id === id) {
        const newLogs = log ? [...t.logs, { timestamp: new Date().toISOString(), message: log.msg, type: log.type }] : t.logs;
        return { ...t, ...updates, logs: newLogs };
      }
      return t;
    }));
  };

  const currentTxn = transactions.find(t => t.id === activeTxnId);
  const currentAdminTxn = transactions.find(t => t.id === adminTxnId);
  
  const totalEscrowVolume = transactions.reduce((acc, t) => acc + Number(t.product.amount), 0);
  const settledFunds = transactions.filter(t => t.status === 'FUNDS_RELEASED').reduce((acc, t) => acc + Number(t.product.amount), 0);
  const activeVerifications = transactions.filter(t => t.status === 'VERIFYING').length;
  const globalSuccessRate = transactions.length > 0 ? Math.round((transactions.filter(t => ['APPROVED', 'FUNDS_RELEASED'].includes(t.status)).length / transactions.length) * 100) : 0;

  const sellerEarnings = transactions.filter(t => t.status === 'FUNDS_RELEASED').reduce((acc, t) => acc + Number(t.product.amount), 0);
  const pendingCollection = transactions.filter(t => t.status === 'APPROVED').reduce((acc, t) => acc + Number(t.product.amount), 0);

  const startOracleScan = async (id: string) => {
    const t = transactions.find(x => x.id === id);
    if (!t) return;
    setIsProcessing(true);
    dbUpdate(id, { status: 'VERIFYING' });
    
    await new Promise(resolve => setTimeout(resolve, 3000));

    try {
      let files: RepoFile[] = [];
      let repoName = t.product.sourceType === 'github' ? t.product.repoUrl || 'Remote Repo' : 'Local Cluster';

      if (t.product.sourceType === 'github' && t.product.repoUrl) {
        const parsed = parseGitHubUrl(t.product.repoUrl);
        if (!parsed) throw new Error("Invalid repository identifier.");
        files = await fetchRepoFiles(parsed.owner, parsed.repo);
      } else if (t.product.sourceType === 'zip' && t.product.localFiles) {
        files = t.product.localFiles;
      }

      const results = await performPseudoAnalysis(files, t.product.description, repoName);
      const reportMd = generateBSReport(results);
      const finalStatus: EscrowStatus = results.score >= 70 ? 'APPROVED' : 'REJECTED';
      
      dbUpdate(id, {
        status: finalStatus,
        compliance_score: results.score,
        detailed_report: reportMd,
        analysis_payload: results
      }, { msg: `Verification Finalized. Score: ${results.score}%. Status: ${finalStatus}.`, type: 'success' });
    } catch (e: any) {
      dbUpdate(id, { status: 'VERIFICATION_ERROR' }, { msg: `Audit Core Error: ${e.message}`, type: 'error' });
    } finally {
      setIsProcessing(false);
    }
  };

  const simulatePayment = async () => {
    if (!currentTxn) return;
    setIsPaying(true);
    await new Promise(resolve => setTimeout(resolve, 2000));
    dbUpdate(currentTxn.id, { status: 'PAYMENT_RECEIVED' }, { msg: `Escrow deposit received at pool address ${ESCROW_POOL_UPI}`, type: 'success' });
    setIsPaying(false);
    setTimeout(() => startOracleScan(currentTxn.id), 800);
  };

  const handleDownloadPDF = async () => {
    if (!currentTxn || !reportRef.current) return;
    setIsExporting(true);
    try {
      const element = reportRef.current;
      const canvas = await html2canvas(element, { scale: 2, useCORS: true, backgroundColor: '#ffffff' });
      const imgData = canvas.toDataURL('image/png');
      const pdf = new jsPDF('p', 'pt', 'a4');
      const pdfWidth = pdf.internal.pageSize.getWidth();
      const imgWidth = canvas.width;
      const imgHeight = canvas.height;
      const ratio = pdfWidth / imgWidth;
      const totalPdfHeight = imgHeight * ratio;
      pdf.addImage(imgData, 'PNG', 0, 0, pdfWidth, totalPdfHeight);
      pdf.save(`VOKO_AUDIT_${currentTxn.id}.pdf`);
    } catch (error) {
      console.error("PDF Export failed", error);
    } finally {
      setIsExporting(false);
    }
  };

  // Fixed: Added handleZipUpload function to process uploaded ZIP archives and update state.
  const handleZipUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    setIsProcessing(true);
    try {
      const files = await processZipFile(file);
      setZipFiles(files);
    } catch (error) {
      console.error("ZIP processing failed", error);
    } finally {
      setIsProcessing(false);
    }
  };

  const createContract = (data: any) => {
    const id = 'VK-' + Math.random().toString(36).substr(2, 6).toUpperCase();
    const newTxn: TransactionDetails = {
      id,
      seller: { name: data.s_name, upi_id: data.s_upi, email: data.s_email },
      buyer: { email: data.b_email },
      product: { 
        description: data.p_desc, 
        repoUrl: sourceType === 'github' ? data.p_url : undefined,
        localFiles: sourceType === 'zip' ? (zipFiles || []) : undefined,
        amount: data.p_amount,
        sourceType
      },
      status: 'CREATED',
      timestamp: new Date().toISOString(),
      logs: [{ timestamp: new Date().toISOString(), message: "Voko escrow handshake initialized.", type: 'info' }]
    };
    setTransactions([newTxn, ...transactions]);
    setSellerSubView('dashboard');
    setZipFiles(null);
  };

  // UPI Link Logic
  const buyerUpiLink = currentTxn ? `upi://pay?pa=${ESCROW_POOL_UPI}&pn=VokoEscrowPool&am=${currentTxn.product.amount}&cu=INR&tn=Escrow_${currentTxn.id}` : '';
  const sellerPayoutUpiLink = currentAdminTxn ? `upi://pay?pa=${currentAdminTxn.seller.upi_id}&pn=${encodeURIComponent(currentAdminTxn.seller.name)}&am=${currentAdminTxn.product.amount}&cu=INR&tn=VokoPayout_${currentAdminTxn.id}` : '';

  return (
    <div className="min-h-screen bg-slate-50 font-sans text-slate-900 overflow-x-hidden">
      
      {/* Hidden Print Container */}
      <div className="fixed -left-[9999px]">
        <div ref={reportRef} className="w-[800px] p-20 bg-white">
          <h1 className="text-4xl font-black mb-10">VOKO INTEGRITY REPORT</h1>
          <p className="text-xl italic">{currentTxn?.detailed_report}</p>
        </div>
      </div>

      <header className="bg-white border-b border-slate-200 h-16 px-8 sticky top-0 z-[100] flex justify-between items-center shadow-sm">
        <div className="flex items-center space-x-3 cursor-pointer" onClick={() => { setActiveTxnId(null); setAdminTxnId(null); }}>
          <div className="w-10 h-10 bg-slate-900 rounded-lg flex items-center justify-center shadow-lg"><svg className="w-6 h-6 text-blue-500" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="3" d="M13 10V3L4 14h7v7l9-11h-7z"/></svg></div>
          <div><h1 className="text-xl font-black uppercase tracking-tighter text-slate-950 italic leading-none">VOKO</h1><p className="text-[9px] font-bold text-slate-400 uppercase tracking-widest mt-1">Architecting Trust</p></div>
        </div>
        <nav className="flex bg-slate-100 p-1 rounded-xl">
          {(['seller', 'buyer', 'admin'] as const).map(r => (
            <button key={r} onClick={() => { setRole(r); setActiveTxnId(null); setAdminTxnId(null); }} className={`px-6 py-2 rounded-lg text-[10px] font-black uppercase tracking-widest transition-all ${role === r ? 'bg-white text-slate-950 shadow-sm' : 'text-slate-400 hover:text-slate-600'}`}>
              {r}
            </button>
          ))}
        </nav>
      </header>

      <main className="max-w-6xl mx-auto p-8">
        {role === 'seller' && (
          <div className="space-y-8 animate-in fade-in duration-500">
            <div className="flex justify-between items-center">
               <div><h2 className="text-4xl font-black text-slate-900 italic tracking-tight">{sellerSubView === 'create' ? 'Initiate Contract' : 'Vault'}</h2></div>
               <div className="flex bg-white p-1 rounded-xl border border-slate-200">
                  <button onClick={() => setSellerSubView('create')} className={`px-6 py-2.5 rounded-lg text-[10px] font-black uppercase tracking-widest transition-all ${sellerSubView === 'create' ? 'bg-slate-900 text-white' : 'text-slate-400 hover:text-slate-700'}`}>New Contract</button>
                  <button onClick={() => setSellerSubView('dashboard')} className={`px-6 py-2.5 rounded-lg text-[10px] font-black uppercase tracking-widest transition-all ${sellerSubView === 'dashboard' ? 'bg-slate-900 text-white' : 'text-slate-400 hover:text-slate-700'}`}>Dashboard</button>
               </div>
            </div>

            {sellerSubView === 'create' ? (
              <form onSubmit={(e: any) => { e.preventDefault(); createContract(Object.fromEntries(new FormData(e.target))); }} className="bg-white p-10 rounded-3xl shadow-sm border border-slate-200 space-y-8 max-w-3xl mx-auto">
                <div className="grid grid-cols-2 gap-8">
                  <div className="space-y-2"><label className="text-[10px] font-black text-slate-400 uppercase tracking-widest ml-2">Your Name</label><input required name="s_name" className="w-full bg-slate-50 border border-slate-200 rounded-xl p-4 font-bold" placeholder="E.g. John Doe" /></div>
                  <div className="space-y-2"><label className="text-[10px] font-black text-slate-400 uppercase tracking-widest ml-2">Payout UPI ID</label><input required name="s_upi" className="w-full bg-slate-50 border border-slate-200 rounded-xl p-4 font-bold" placeholder="yourname@upi" /></div>
                </div>
                <div className="space-y-2"><label className="text-[10px] font-black text-slate-400 uppercase tracking-widest ml-2">Buyer Email</label><input required name="b_email" type="email" className="w-full bg-slate-50 border border-slate-200 rounded-xl p-4 font-bold" placeholder="buyer@client.com" /></div>
                
                <div className="pt-4 border-t border-slate-100 space-y-6">
                  <div className="flex bg-slate-100 p-1 rounded-xl w-fit">
                    <button type="button" onClick={() => setSourceType('github')} className={`px-8 py-2 rounded-lg text-[10px] font-black uppercase tracking-widest transition-all ${sourceType === 'github' ? 'bg-white shadow-sm text-blue-600' : 'text-slate-400'}`}>GitHub</button>
                    <button type="button" onClick={() => setSourceType('zip')} className={`px-8 py-2 rounded-lg text-[10px] font-black uppercase tracking-widest transition-all ${sourceType === 'zip' ? 'bg-white shadow-sm text-blue-600' : 'text-slate-400'}`}>ZIP</button>
                  </div>
                  {sourceType === 'github' ? (
                    <input required name="p_url" className="w-full bg-slate-50 border border-slate-200 rounded-xl p-4 font-bold" placeholder="Repo URL (https://github.com/...)" />
                  ) : (
                    <div className="p-10 border-2 border-dashed border-slate-200 rounded-2xl text-center">
                       <input type="file" accept=".zip" onChange={handleZipUpload} className="hidden" id="zip-seller" />
                       <label htmlFor="zip-seller" className="cursor-pointer text-[10px] font-black uppercase tracking-widest text-slate-400 hover:text-blue-500 transition-colors">{zipFiles ? `${zipFiles.length} files detected` : 'Choose Project ZIP'}</label>
                    </div>
                  )}
                  <div className="space-y-2"><label className="text-[10px] font-black text-slate-400 uppercase tracking-widest ml-2">Integrity Ruleset</label><textarea required name="p_desc" rows={4} className="w-full bg-slate-50 border border-slate-200 rounded-2xl p-4 font-bold resize-none" placeholder="Describe compliance requirements..." /></div>
                </div>

                <div className="flex items-center gap-8 bg-slate-900 p-8 rounded-3xl text-white">
                  <div className="flex-grow space-y-2"><label className="text-[10px] font-black text-slate-500 uppercase tracking-widest ml-2">Escrow (INR)</label><div className="flex items-center text-4xl font-black italic">₹<input required name="p_amount" type="number" className="bg-transparent border-none p-0 w-full focus:ring-0 placeholder:text-slate-800" placeholder="0" /></div></div>
                  <button className="px-10 py-5 bg-blue-600 rounded-2xl text-xs font-black uppercase tracking-widest hover:bg-blue-500 transition-all shadow-xl active:scale-95">Lock Contract</button>
                </div>
              </form>
            ) : (
              <div className="space-y-8">
                 <div className="grid grid-cols-3 gap-6">
                    <div className="bg-white p-6 rounded-2xl border border-slate-200 text-center shadow-sm"><p className="text-[10px] font-black text-slate-400 uppercase tracking-widest mb-2">Earnings</p><p className="text-3xl font-black italic">₹{sellerEarnings}</p></div>
                    <div className="bg-white p-6 rounded-2xl border border-slate-200 text-center shadow-sm"><p className="text-[10px] font-black text-slate-400 uppercase tracking-widest mb-2">Pending</p><p className="text-3xl font-black italic">₹{pendingCollection}</p></div>
                    <div className="bg-white p-6 rounded-2xl border border-slate-200 text-center shadow-sm"><p className="text-[10px] font-black text-slate-400 uppercase tracking-widest mb-2">Integrity</p><p className="text-3xl font-black italic">{globalSuccessRate}%</p></div>
                 </div>
                 <div className="bg-white rounded-3xl border border-slate-200 overflow-hidden shadow-sm">
                    <table className="w-full text-left">
                       <thead className="bg-slate-50 border-b"><tr><th className="px-8 py-4 text-[10px] font-black uppercase text-slate-400">ID</th><th className="px-8 py-4 text-[10px] font-black uppercase text-slate-400">Status</th><th className="px-8 py-4 text-[10px] font-black uppercase text-slate-400 text-right">Amount</th></tr></thead>
                       <tbody>{transactions.map(t => (
                         <tr key={t.id} onClick={() => { setActiveTxnId(t.id); setRole('buyer'); }} className="hover:bg-slate-50 cursor-pointer border-b last:border-0 transition-colors">
                            <td className="px-8 py-6 font-black text-lg italic">{t.id}</td>
                            <td className="px-8 py-6"><span className="text-[9px] font-black uppercase tracking-widest px-3 py-1 bg-slate-100 rounded-full">{t.status}</span></td>
                            <td className="px-8 py-6 text-right font-black text-lg italic">₹{t.product.amount}</td>
                         </tr>
                       ))}</tbody>
                    </table>
                 </div>
              </div>
            )}
          </div>
        )}

        {role === 'buyer' && (
          <div className="animate-in fade-in duration-500">
            {activeTxnId ? (
              <div className="space-y-8">
                 <button onClick={() => setActiveTxnId(null)} className="text-[10px] font-black text-slate-400 hover:text-slate-950 uppercase tracking-widest flex items-center gap-2 italic"><svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M15 19l-7-7 7-7"/></svg> Back</button>
                 <div className="bg-white p-10 rounded-3xl shadow-sm border border-slate-200 grid grid-cols-1 md:grid-cols-2 gap-12 relative overflow-hidden">
                    <div className="space-y-6">
                       <div><p className="text-[9px] font-black text-slate-300 uppercase tracking-widest mb-2">REF: {currentTxn?.id}</p><h2 className="text-6xl font-black italic text-slate-950 tracking-tighter">₹{currentTxn?.product.amount}</h2></div>
                       <p className="text-slate-400 font-bold leading-relaxed italic">{currentTxn?.product.description}</p>
                       <div className="p-4 bg-slate-50 rounded-xl border border-slate-100 text-[11px] font-mono truncate italic">{currentTxn?.product.repoUrl || 'Local Archive'}</div>
                    </div>
                    <div className="flex flex-col justify-center items-center text-center space-y-6">
                       {currentTxn?.status === 'CREATED' ? (
                          <>
                             <p className="text-slate-500 font-bold italic text-sm">Escrow portal active. Deposit required to initiate audit sequence.</p>
                             <button onClick={() => setIsPaying(true)} className="w-full py-5 bg-blue-600 text-white rounded-2xl text-[10px] font-black uppercase tracking-widest shadow-xl hover:bg-blue-500 transition-all">Pay via UPI</button>
                          </>
                       ) : currentTxn?.status === 'VERIFYING' ? (
                          <div className="animate-pulse space-y-4">
                             <div className="w-16 h-16 border-8 border-slate-100 border-t-blue-600 rounded-full animate-spin mx-auto"></div>
                             <p className="text-[10px] font-black uppercase text-blue-600 tracking-widest italic">Scanning Node Cluster...</p>
                          </div>
                       ) : (['APPROVED', 'FUNDS_RELEASED'].includes(currentTxn?.status || '')) ? (
                          <div className="space-y-6">
                             <div className="text-7xl font-black text-emerald-500 italic leading-none">{currentTxn?.compliance_score}%</div>
                             <button onClick={handleDownloadPDF} disabled={isExporting} className="w-full py-4 border-2 border-emerald-500 text-emerald-600 rounded-2xl text-[10px] font-black uppercase tracking-widest hover:bg-emerald-50 transition-all italic">Download Certificate</button>
                          </div>
                       ) : <div className="text-center p-8 bg-rose-50 rounded-2xl border border-rose-100"><p className="text-5xl font-black text-rose-600 italic leading-none">{currentTxn?.compliance_score}%</p><p className="text-[9px] font-black uppercase text-rose-600 mt-4 tracking-widest italic">Verification Failed</p></div>}
                    </div>
                 </div>
                 {currentTxn?.analysis_payload && <ResultsDisplay results={currentTxn.analysis_payload} />}
              </div>
            ) : (
              <div className="space-y-8 max-w-2xl mx-auto text-center">
                 <h2 className="text-4xl font-black text-slate-900 italic tracking-tight">Access Vault</h2>
                 <p className="text-slate-400 font-bold italic">Verify deliverables through forensic integrity checking.</p>
                 <div className="relative mt-8">
                    <input value={buyerSearch} onChange={e => setBuyerSearch(e.target.value)} className="w-full bg-white border border-slate-200 rounded-2xl p-5 font-bold shadow-sm focus:ring-4 focus:ring-blue-500/5 transition-all outline-none italic" placeholder="Identification via Buyer Email..." />
                    <div className="absolute right-5 top-5 text-slate-300"><svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z"/></svg></div>
                 </div>
                 <div className="grid grid-cols-1 gap-4 mt-8">
                    {transactions.filter(t => t.buyer.email.toLowerCase().includes(buyerSearch.toLowerCase())).map(t => (
                      <div key={t.id} onClick={() => setActiveTxnId(t.id)} className="bg-white p-6 rounded-2xl border border-slate-200 flex justify-between items-center hover:translate-x-2 transition-all cursor-pointer group shadow-sm">
                         <div className="text-left">
                            <p className="text-xl font-black italic group-hover:text-blue-600 transition-colors">{t.id}</p>
                            <p className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">{t.seller.name}</p>
                         </div>
                         <div className="text-right">
                            <p className="text-xl font-black italic">₹{t.product.amount}</p>
                            <span className="text-[8px] font-black uppercase tracking-widest px-2 py-0.5 bg-slate-100 rounded-full">{t.status}</span>
                         </div>
                      </div>
                    ))}
                    {buyerSearch && transactions.filter(t => t.buyer.email.toLowerCase().includes(buyerSearch.toLowerCase())).length === 0 && <p className="text-[10px] font-black uppercase tracking-widest text-slate-300 italic pt-10">No agreements found</p>}
                 </div>
              </div>
            )}
          </div>
        )}

        {role === 'admin' && (
          <div className="animate-in fade-in duration-500 grid grid-cols-1 lg:grid-cols-12 gap-8 pb-20">
             <div className="lg:col-span-8 space-y-8">
                <div className="flex justify-between items-end">
                   <h2 className="text-4xl font-black text-slate-900 italic tracking-tight">Audit Console</h2>
                   <div className="bg-slate-900 px-6 py-3 rounded-xl text-center"><p className="text-[9px] font-black text-slate-500 uppercase tracking-widest mb-1">Total Volume</p><p className="text-2xl font-black text-blue-400 italic">₹{totalEscrowVolume}</p></div>
                </div>
                <div className="bg-white rounded-3xl border border-slate-200 overflow-hidden shadow-sm">
                   <table className="w-full text-left">
                      <thead className="bg-slate-50 border-b"><tr><th className="px-6 py-4 text-[9px] font-black uppercase text-slate-400">Node ID</th><th className="px-6 py-4 text-[9px] font-black uppercase text-slate-400 text-center">Score</th><th className="px-6 py-4 text-[9px] font-black uppercase text-slate-400 text-right">Settlement</th></tr></thead>
                      <tbody>{transactions.map(t => (
                        <tr key={t.id} onClick={() => setAdminTxnId(t.id)} className={`hover:bg-slate-50 cursor-pointer border-b last:border-0 transition-colors ${adminTxnId === t.id ? 'bg-blue-50' : ''}`}>
                           <td className="px-6 py-5"><p className="font-black text-lg italic">{t.id}</p><p className="text-[8px] font-bold text-slate-400 uppercase tracking-widest italic">{t.seller.name} → {t.buyer.email.slice(0, 10)}...</p></td>
                           <td className="px-6 py-5 text-center"><span className={`text-2xl font-black italic ${t.compliance_score && t.compliance_score >= 70 ? 'text-emerald-500' : 'text-slate-200'}`}>{t.compliance_score || '--'}%</span></td>
                           <td className="px-6 py-5 text-right"><p className="font-black text-lg italic leading-none">₹{t.product.amount}</p><p className="text-[8px] font-black uppercase text-blue-600 tracking-widest mt-2 italic">{t.status}</p></td>
                        </tr>
                      ))}</tbody>
                   </table>
                </div>
             </div>
             <div className="lg:col-span-4 space-y-6">
                {currentAdminTxn ? (
                   <div className="bg-white p-8 rounded-3xl border border-slate-200 shadow-sm sticky top-24">
                      <div className="flex justify-between items-center mb-6">
                         <h3 className="text-[10px] font-black text-slate-400 uppercase tracking-widest italic">Audit Telemetry</h3>
                         <button onClick={() => setAdminTxnId(null)} className="text-slate-300 hover:text-slate-900"><svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M6 18L18 6M6 6l12 12"/></svg></button>
                      </div>
                      <div className="bg-slate-900 p-6 rounded-2xl mb-8 font-mono text-[10px] space-y-2 h-40 overflow-y-auto custom-scrollbar">
                         {currentAdminTxn.logs.map((log, i) => (
                           <div key={i} className="flex gap-2 border-b border-white/5 pb-1">
                              <span className="text-slate-600">{new Date(log.timestamp).toLocaleTimeString()}</span>
                              <span className={log.type === 'error' ? 'text-rose-400' : log.type === 'success' ? 'text-emerald-400' : 'text-blue-400'}>{log.message}</span>
                           </div>
                         ))}
                      </div>
                      <div className="space-y-4">
                         {currentAdminTxn.status === 'APPROVED' ? (
                            <button onClick={() => setShowAdminSettlement(true)} className="w-full py-4 bg-emerald-600 text-white rounded-xl text-[10px] font-black uppercase tracking-widest shadow-lg hover:bg-emerald-700 transition-all">Authorize Trust Payout</button>
                         ) : (
                            <button disabled className="w-full py-4 bg-slate-100 text-slate-300 rounded-xl text-[10px] font-black uppercase tracking-widest italic">Audit Verification Pending</button>
                         )}
                         <button onClick={() => { if(confirm("Clear trust node?")) dbUpdate(currentAdminTxn.id, { status: 'CREATED', compliance_score: 0 }); }} className="w-full py-4 text-slate-400 hover:text-rose-600 text-[9px] font-black uppercase tracking-widest transition-colors">Factory Reset Node</button>
                      </div>
                   </div>
                ) : <div className="p-12 border-2 border-dashed border-slate-200 rounded-3xl text-center text-slate-300 font-black uppercase tracking-widest text-xs italic">Select trust node to audit</div>}
             </div>
          </div>
        )}
      </main>

      {/* Buyer Payment Modal */}
      {isPaying && currentTxn && (
        <div className="fixed inset-0 bg-slate-950/95 backdrop-blur-xl z-[300] flex items-center justify-center p-6 animate-in fade-in duration-300">
           <div className="bg-white w-full max-w-md rounded-3xl overflow-hidden shadow-2xl ring-1 ring-white/10 animate-in zoom-in-95">
              <div className="bg-slate-900 p-8 text-center relative">
                 <button onClick={() => setIsPaying(false)} className="absolute top-6 right-6 text-slate-500 hover:text-white"><svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M6 18L18 6M6 6l12 12"/></svg></button>
                 <p className="text-[9px] font-black text-slate-500 uppercase tracking-[0.4em] mb-2">Escrow Pool Intake</p>
                 <h2 className="text-4xl font-black text-white italic tracking-tight leading-none">₹{currentTxn.product.amount}</h2>
              </div>
              <div className="p-10 flex flex-col items-center">
                 <div className="p-4 bg-slate-50 rounded-2xl border-2 border-slate-100 mb-8">
                    <img src={`https://api.qrserver.com/v1/create-qr-code/?size=200x200&data=${encodeURIComponent(buyerUpiLink)}`} className="w-48 h-48" alt="UPI QR" />
                 </div>
                 <div className="w-full space-y-6 text-center">
                    <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest italic">POOL ADDR: {ESCROW_POOL_UPI}</p>
                    <button onClick={simulatePayment} className="w-full py-4 bg-blue-600 text-white rounded-xl text-[10px] font-black uppercase tracking-widest shadow-xl hover:bg-blue-500 transition-all active:scale-95">Verify Deposit Successful</button>
                 </div>
              </div>
           </div>
        </div>
      )}

      {/* Admin Settlement Modal */}
      {showAdminSettlement && currentAdminTxn && (
        <div className="fixed inset-0 bg-slate-950/95 backdrop-blur-xl z-[300] flex items-center justify-center p-6 animate-in fade-in duration-300">
           <div className="bg-white w-full max-w-md rounded-3xl overflow-hidden shadow-2xl ring-1 ring-white/10 animate-in zoom-in-95">
              <div className="bg-emerald-900 p-8 text-center relative">
                 <button onClick={() => setShowAdminSettlement(false)} className="absolute top-6 right-6 text-emerald-500 hover:text-white"><svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M6 18L18 6M6 6l12 12"/></svg></button>
                 <p className="text-[9px] font-black text-emerald-500 uppercase tracking-[0.4em] mb-2">Trust Release Handshake</p>
                 <h2 className="text-4xl font-black text-white italic tracking-tight leading-none">₹{currentAdminTxn.product.amount}</h2>
              </div>
              <div className="p-10 flex flex-col items-center">
                 <div className="p-4 bg-emerald-50 rounded-2xl border-2 border-emerald-100 mb-8">
                    <img src={`https://api.qrserver.com/v1/create-qr-code/?size=200x200&data=${encodeURIComponent(sellerPayoutUpiLink)}`} className="w-48 h-48" alt="Payout QR" />
                 </div>
                 <div className="w-full space-y-6 text-center">
                    <div className="space-y-1">
                       <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest italic">SELLER DESTINATION</p>
                       <p className="text-sm font-black italic text-slate-900">{currentAdminTxn.seller.upi_id}</p>
                    </div>
                    <button onClick={async () => {
                       dbUpdate(currentAdminTxn.id, { status: 'FUNDS_RELEASED' }, { msg: `Trust Release of ₹${currentAdminTxn.product.amount} finalized to ${currentAdminTxn.seller.upi_id}`, type: 'success' });
                       setShowAdminSettlement(false);
                    }} className="w-full py-4 bg-emerald-600 text-white rounded-xl text-[10px] font-black uppercase tracking-widest shadow-xl hover:bg-emerald-500 transition-all active:scale-95">Confirm Manual Transfer</button>
                    <p className="text-[9px] text-slate-400 font-bold italic">Scan the QR with your banking app to initiate transfer from Voko Pool.</p>
                 </div>
              </div>
           </div>
        </div>
      )}

      {isProcessing && (
        <div className="fixed inset-0 bg-slate-950/98 backdrop-blur-2xl z-[500] flex flex-col items-center justify-center p-24 text-center text-white">
          <div className="w-20 h-20 border-8 border-white/5 border-t-blue-500 rounded-full animate-spin mb-10"></div>
          <h2 className="text-4xl font-black italic tracking-tight italic">FORENSIC SYNC</h2>
          <p className="text-slate-500 font-bold uppercase text-[10px] tracking-[1em] mt-8 animate-pulse italic">Traversing Trust Node Infrastructure...</p>
        </div>
      )}
    </div>
  );
};

export default App;
