
export interface RepoFile {
  path: string;
  content: string;
  type: 'file' | 'dir';
}

// Fixed: Added patterns and antiPatterns to ComplianceRule to match usage in analysisService.ts
export interface ComplianceRule {
  id: string;
  title: string;
  description: string;
  category: 'security' | 'quality' | 'standard' | 'custom';
  severity: 'high' | 'medium' | 'low';
  // Regex patterns to match code violations
  patterns?: string[];
  // String fragments to flag as bad practices
  antiPatterns?: string[];
}

export interface IntentChecklistItem {
  requirement: string;
  status: 'implemented' | 'missing' | 'partial';
  explanation: string;
  snippet?: string;
  file?: string;
  confidence: number;
}

export interface CodeMetrics {
  totalLines: number;
  commentLines: number;
  avgLineLength: number;
  maxNestingDepth: number;
  docDensity: number;
  fileDiversity: string[];
}

export interface AnalysisFinding {
  fileName: string;
  ruleId: string;
  ruleTitle: string;
  category: 'security' | 'quality' | 'standard' | 'custom';
  severity: 'high' | 'medium' | 'low';
  message: string;
  lineRange?: string;
  recommendation: string;
  snippet?: string;
}

export interface ComplianceResult {
  score: number;
  intentChecklist: IntentChecklistItem[];
  findings: AnalysisFinding[];
  metrics: CodeMetrics;
  overallAnalysis: string;
  timestamp: string;
  repoIdentifier: string;
  totalFilesScanned: number;
}

export type EscrowStatus = 
  | 'CREATED' 
  | 'AWAITING_PAYMENT' 
  | 'PAYMENT_RECEIVED' 
  | 'VERIFYING' 
  | 'APPROVED' 
  | 'REJECTED' 
  | 'FUNDS_RELEASED' 
  | 'VERIFICATION_ERROR';

export interface TransactionLog {
  timestamp: string;
  message: string;
  type: 'info' | 'success' | 'warning' | 'error';
}

export interface TransactionDetails {
  id: string;
  seller: {
    name: string;
    upi_id: string;
    email: string;
  };
  buyer: {
    email: string;
  };
  product: {
    description: string;
    repoUrl?: string;
    localFiles?: RepoFile[]; // Added to store ZIP contents
    amount: string;
    sourceType: 'github' | 'zip';
  };
  status: EscrowStatus;
  compliance_score?: number;
  detailed_report?: string;
  analysis_payload?: ComplianceResult;
  timestamp: string;
  payout_timestamp?: string;
  logs: TransactionLog[];
}

export type UserRole = 'seller' | 'buyer' | 'admin';
