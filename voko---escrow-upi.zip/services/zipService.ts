
import JSZip from 'jszip';
import { RepoFile } from '../types';

export const processZipFile = async (file: File): Promise<RepoFile[]> => {
  const zip = new JSZip();
  const contents = await zip.loadAsync(file);
  const files: RepoFile[] = [];

  const relevantExtensions = [
    '.js', '.jsx', '.ts', '.tsx', '.py', '.go', '.java', '.c', '.cpp', '.h', '.hpp', 
    '.rs', '.php', '.rb', '.json', '.yml', '.yaml', '.md', '.css', '.html', '.sh'
  ];

  const ignoredDirs = ['node_modules', '.git', 'dist', 'build', 'vendor', 'out', 'target', '.next'];

  const promises: Promise<void>[] = [];

  contents.forEach((relativePath, zipEntry) => {
    if (zipEntry.dir) return;

    const pathParts = relativePath.split('/');
    if (pathParts.some(part => ignoredDirs.includes(part))) return;

    const ext = relativePath.substring(relativePath.lastIndexOf('.'));
    const isConfig = relativePath.toLowerCase().includes('config') || 
                     relativePath.toLowerCase().endsWith('package.json') ||
                     relativePath.toLowerCase().endsWith('dockerfile');

    if (relevantExtensions.includes(ext) || isConfig) {
      promises.push(
        zipEntry.async('string').then(content => {
          files.push({
            path: relativePath,
            content: content.slice(0, 15000), // Match fetchRepoFiles behavior
            type: 'file'
          });
        })
      );
    }
  });

  await Promise.all(promises);
  return files;
};
