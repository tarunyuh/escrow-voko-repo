
import { RepoFile, ComplianceResult, IntentChecklistItem } from '../types';

const JARGON = [
  "Suboptimal algorithmic density detected in critical path logic.",
  "Structural entropy within the modular hierarchy suggests potential maintainability regression.",
  "Heuristic overlap in logic nodes indicates a lack of definitive separation of concerns.",
  "Non-linear execution patterns observed in highly nested control structures.",
  "Variable nomenclature demonstrates high semantic correlation with domain-specific intent.",
  "Memory-efficient object lifecycle management verified in core service layers.",
  "Asynchronous event handling demonstrates robust state-transition integrity."
];

const STRENGTHS = [
  "High syntactic consistency across directory clusters.",
  "Robust modular encapsulation of logic nodes.",
  "Minimal footprint of legacy technical debt signatures.",
  "Consistent adherence to modern functional paradigms."
];

const GAPS = [
  "Inconsistent comment-to-logic ratio in peripheral modules.",
  "Elevated cyclomatic complexity in primary entry points.",
  "Potential for logic-branch overflow in edge-case handling.",
  "Redundant symbolic declarations in utility namespaces."
];

export const performPseudoAnalysis = async (
  files: RepoFile[],
  intent: string,
  repoName: string
): Promise<ComplianceResult> => {
  // Fix: Explicitly type 'words' as string[] to prevent the TypeScript compiler from inferring 'never[]' (which causes the 'length' error on line 35)
  const words: string[] = intent.toLowerCase().match(/\w+/g) || [];
  const keyTerms = words.filter(w => w.length > 5);
  
  const checklist: IntentChecklistItem[] = keyTerms.slice(0, 6).map((term, idx) => {
    const matches = files.filter(f => f.content.toLowerCase().includes(term));
    const confidence = matches.length > 0 ? 70 + Math.floor(Math.random() * 25) : 30 + Math.floor(Math.random() * 20);
    const status = confidence > 85 ? 'implemented' : confidence > 55 ? 'partial' : 'missing';
    
    return {
      requirement: `Requirement: ${term.charAt(0).toUpperCase() + term.slice(1)} Verification`,
      status,
      explanation: status === 'implemented' 
        ? `Direct symbolic mapping found for "${term}" across ${matches.length} nodes.`
        : `Heuristic markers for "${term}" are sparse or architecturally obscured.`,
      file: matches[0]?.path || 'General Cluster',
      confidence
    };
  });

  // Calculate BS Score
  const score = Math.floor(75 + (Math.random() * 20));
  const totalLines = files.reduce((acc, f) => acc + f.content.split('\n').length, 0);

  return {
    score,
    intentChecklist: checklist,
    findings: [],
    metrics: {
      totalLines,
      commentLines: Math.floor(totalLines * 0.12),
      avgLineLength: 68,
      maxNestingDepth: 4,
      docDensity: 12,
      fileDiversity: Array.from(new Set(files.map(f => f.path.split('.').pop() || 'raw')))
    },
    overallAnalysis: JARGON[Math.floor(Math.random() * JARGON.length)],
    timestamp: new Date().toISOString(),
    repoIdentifier: repoName,
    totalFilesScanned: files.length
  };
};

export const generateBSReport = (result: ComplianceResult): string => {
  const getRand = (arr: string[]) => arr[Math.floor(Math.random() * arr.length)];
  
  return `
# 1. OVERALL COMPLIANCE VERDICT
**STATUS: ${result.score > 80 ? 'HIGH INTEGRITY' : 'MODERATE RISK'}**
Based on a heuristic traversal of ${result.totalFilesScanned} logic nodes, the system reports a compliance score of **${result.score}%**. The structural architecture demonstrates a ${result.score > 85 ? 'cohesive' : 'dispersed'} alignment with the specified intent.

# 2. EXECUTIVE SUMMARY
## Strengths
- ${getRand(STRENGTHS)}
- ${getRand(STRENGTHS)}
- ${getRand(STRENGTHS)}

## Areas for Improvement
- ${getRand(GAPS)}
- ${getRand(GAPS)}
- ${getRand(GAPS)}

# 3. COMPLIANCE CHECKLIST
| Requirement Node | Verification Status | Forensic Confidence |
| :--- | :--- | :--- |
${result.intentChecklist.map(c => `| ${c.requirement} | ${c.status.toUpperCase()} | ${c.confidence}% |`).join('\n')}

# 4. DETAILED FINDINGS & ACTIONABLE RECOMMENDATIONS
### Finding: Structural Entropy
${getRand(JARGON)}
**Recommendation**: Implement a rigorous decoupling of non-linear service modules to minimize algorithmic friction.

### Finding: Symbolic Redundancy
Logic patterns detected in ${result.intentChecklist[0]?.file} suggest a violation of the DRY (Don't Repeat Yourself) principle at the heuristic level.
**Recommendation**: Refactor redundant logic nodes into a centralized symbolic repository.

# 5. CONCLUSION
The codebase is currently rated at ${result.score}% compliance. While the primary logic pathways are functional, significant architectural optimization is required to reach maximum forensic certification levels.
  `.trim();
};
