
import { RepoFile, ComplianceRule, ComplianceResult, AnalysisFinding, CodeMetrics } from '../types';

/**
 * Extracts symbolic signatures (Functions, Classes, Imports) to provide a "Structural Map".
 */
const extractSymbolicMap = (content: string): string[] => {
  const symbols: string[] = [];
  const lines = content.split('\n');
  
  const functionRegex = /(?:export\s+)?(?:async\s+)?function\s+([a-zA-Z0-9_]+)/g;
  const arrowRegex = /const\s+([a-zA-Z0-9_]+)\s*=\s*(?:async\s*)?\([^)]*\)\s*=>/g;
  const classRegex = /(?:export\s+)?class\s+([a-zA-Z0-9_]+)/g;

  lines.forEach(line => {
    let match;
    while ((match = functionRegex.exec(line)) !== null) symbols.push(`Function: ${match[1]}`);
    while ((match = arrowRegex.exec(line)) !== null) symbols.push(`Logic Block: ${match[1]}`);
    while ((match = classRegex.exec(line)) !== null) symbols.push(`Structure: ${match[1]}`);
  });

  return Array.from(new Set(symbols));
};

export const runLocalAnalysis = (
  files: RepoFile[],
  rules: ComplianceRule[],
  repoName: string,
  userIntent: string
): ComplianceResult => {
  const findings: AnalysisFinding[] = [];
  const fileCompliance: Record<string, boolean> = {};
  
  let totalLines = 0;
  let commentLines = 0;
  let maxNestingDepth = 0;
  let totalLineLength = 0;
  const extensions = new Set<string>();
  const globalSymbols: string[] = [];

  files.forEach(file => {
    if (file.type !== 'file') return;
    fileCompliance[file.path] = true;
    
    const symbols = extractSymbolicMap(file.content);
    globalSymbols.push(...symbols.map(s => `${file.path} -> ${s}`));

    const lines = file.content.split('\n');
    totalLines += lines.length;
    extensions.add(file.path.split('.').pop() || 'unknown');

    lines.forEach((line, idx) => {
      const trimmed = line.trim();
      if (!trimmed) return;
      totalLineLength += trimmed.length;
      
      if (trimmed.startsWith('//') || trimmed.startsWith('/*') || trimmed.startsWith('*') || trimmed.startsWith('#')) {
        commentLines++;
      }

      const depth = (line.match(/\{/g) || []).length - (line.match(/\}/g) || []).length;
      if (depth > maxNestingDepth) maxNestingDepth = depth;

      rules.forEach(rule => {
        let isViolation = false;
        if (rule.patterns) {
          rule.patterns.forEach(p => {
            try {
              if (new RegExp(p, 'gi').test(line)) isViolation = true;
            } catch {}
          });
        }
        if (rule.antiPatterns) {
          rule.antiPatterns.forEach(ap => {
            if (line.toLowerCase().includes(ap.toLowerCase())) isViolation = true;
          });
        }

        if (isViolation) {
          findings.push({
            fileName: file.path,
            ruleId: rule.id,
            ruleTitle: rule.title,
            category: rule.category,
            severity: rule.severity,
            message: `Structural Violation: ${rule.title}`,
            lineRange: `${idx + 1}`,
            recommendation: rule.description,
            snippet: trimmed
          });
          fileCompliance[file.path] = false;
        }
      });
    });
  });

  const metrics: CodeMetrics = {
    totalLines,
    commentLines,
    avgLineLength: totalLines > 0 ? Math.round(totalLineLength / totalLines) : 0,
    maxNestingDepth,
    docDensity: totalLines > 0 ? Math.round((commentLines / totalLines) * 100) : 0,
    fileDiversity: Array.from(extensions)
  };

  const compliantCount = Object.values(fileCompliance).filter(v => v).length;
  const techScore = files.length > 0 ? Math.round((compliantCount / files.length) * 100) : 100;

  // Fix: Match ComplianceResult interface exactly (overallAnalysis and intentChecklist added, invalid fields removed)
  return {
    score: techScore,
    findings,
    intentChecklist: [
      {
        requirement: 'Symbol Density',
        status: globalSymbols.length > files.length ? 'implemented' : 'partial',
        explanation: `Identified ${globalSymbols.length} core logic blocks across ${files.length} files.`,
        confidence: 100
      }
    ],
    metrics,
    overallAnalysis: `Local logic scan completed for ${repoName}. Detected ${findings.length} structural violations and mapped ${globalSymbols.length} symbols.`,
    timestamp: new Date().toISOString(),
    repoIdentifier: repoName,
    totalFilesScanned: files.length
  };
};
