
import { RepoFile } from '../types';

export const parseGitHubUrl = (url: string) => {
  try {
    const cleanUrl = url.replace(/\/$/, "");
    const parts = cleanUrl.split("/");
    const repoIndex = parts.indexOf("github.com");
    if (repoIndex === -1 || parts.length < repoIndex + 3) return null;
    return {
      owner: parts[repoIndex + 1],
      repo: parts[repoIndex + 2]
    };
  } catch {
    return null;
  }
};

/**
 * Recursively fetches files from a GitHub repository with increased capacity.
 */
export const fetchRepoFiles = async (
  owner: string, 
  repo: string, 
  path: string = '', 
  depth: number = 0,
  context: { count: number } = { count: 0 }
): Promise<RepoFile[]> => {
  // Prevent excessive depth but allow enough for modern app structures (max 5)
  if (depth > 5 || context.count > 150) return [];

  const apiUrl = `https://api.github.com/repos/${owner}/${repo}/contents/${path}`;
  const response = await fetch(apiUrl);
  
  if (!response.ok) {
    if (response.status === 403) throw new Error("GitHub API rate limit exceeded.");
    if (response.status === 404) throw new Error("Repository path not found.");
    throw new Error(`GitHub API Error: ${response.statusText}`);
  }

  const data = await response.json();
  const files: RepoFile[] = [];
  const items = Array.isArray(data) ? data : [data];

  const relevantExtensions = [
    '.js', '.jsx', '.ts', '.tsx', '.py', '.go', '.java', '.c', '.cpp', '.h', '.hpp', 
    '.rs', '.php', '.rb', '.json', '.sh', '.cs', '.m', '.swift', '.kt', '.sql', '.yaml', '.yml'
  ];

  const sortedItems = items.sort((a, b) => {
    if (a.type === 'dir' && b.type !== 'dir') return -1;
    if (a.type !== 'dir' && b.type === 'dir') return 1;
    return 0;
  });

  for (const item of sortedItems) {
    if (context.count > 150) break;

    if (item.type === 'file') {
      const ext = item.name.substring(item.name.lastIndexOf('.'));
      const isConfig = item.name.toLowerCase().includes('config') || 
                       ['package.json', 'dockerfile', 'makefile', 'go.mod', 'cargo.toml', 'requirements.txt'].includes(item.name.toLowerCase());
      
      if (relevantExtensions.includes(ext) || isConfig) {
        try {
          const contentRes = await fetch(item.download_url);
          if (contentRes.ok) {
            const content = await contentRes.text();
            // Store up to 30k characters per file for better Gemini context
            files.push({
              path: item.path,
              content: content.slice(0, 30000), 
              type: 'file'
            });
            context.count++;
          }
        } catch (e) {
          console.warn(`Skipping ${item.path}`);
        }
      }
    } else if (item.type === 'dir') {
      const ignoredDirs = ['node_modules', '.git', 'dist', 'build', 'vendor', 'out', 'target', '.next', 'public', 'assets', 'test', 'tests', 'docs', '.github', 'coverage'];
      if (!ignoredDirs.includes(item.name)) {
        try {
          const subFiles = await fetchRepoFiles(owner, repo, item.path, depth + 1, context);
          files.push(...subFiles);
        } catch (e) {
          console.warn(`Skipping directory ${item.path}`);
        }
      }
    }
  }

  return files;
};
